import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DepartmentService } from '../../core/department.service';
import { EmployeeService } from '../employees/employees.service';
import { Department } from '../../core/model';
import { Employee } from '../employees/employee.model';
import { SpinnerComponent } from '../../shared/spinner/spinner.component';
import { RouterModule } from '@angular/router';
import { IfUserIsAdminDirective } from '../../shared/directives/if-user-is-admin.directive';
import { forkJoin, Observable } from 'rxjs';

@Component({
  selector: 'app-departments-manage',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    SpinnerComponent,
    IfUserIsAdminDirective,
  ],
  templateUrl: './departments-manage.component.html',
  styleUrls: ['./departments-manage.component.scss'],
})
export class DepartmentsManageComponent implements OnInit {
  private deptService = inject(DepartmentService);
  private empService = inject(EmployeeService);

  loading = true;
  departments: Department[] = [];
  employees: Employee[] = [];
  newDepartmentName = '';
  selectedDepartmentId: string = '';
  selectedEmployeeIds: string[] = [];

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading = true;
    forkJoin({
      departments: this.deptService.getDepartments(),
      employees: this.empService.getEmployees(),
    }).subscribe({
      next: ({ departments, employees }) => {
        this.departments = departments;
        this.employees = employees;
        this.loading = false;
      },
      error: () => (this.loading = false), //stop the spinner but I'm not logging anything here
    });
  }

  createDepartment(): void {
    if (!this.newDepartmentName.trim()) return;

    const newDept: Department = {
      id: '',
      name: this.newDepartmentName.trim(),
      head: 'Unknown',
      employeeCount: 0,
    };

    this.deptService.addDepartment(newDept).subscribe({
      next: () => {
        this.newDepartmentName = ''; //clear the input field
        this.loadData();
      },
      error: (err) => {
        console.error('Error creating department:', err);
      },
    });
  }

  transferEmployees(): void {
    if (!this.selectedDepartmentId || this.selectedEmployeeIds.length === 0)
      return;

    const deptName = this.getDepartmentNameById(this.selectedDepartmentId);
    if (!deptName) return;

    const updateRequests: Observable<any>[] = this.selectedEmployeeIds
      .map((empId) => {
        const emp = this.employees.find((e) => e.id === empId);
        if (!emp) return null;
        const updated: Employee = { ...emp, department: deptName };
        return this.empService.updateEmployee(empId, updated);
      })
      .filter((req): req is Observable<any> => req !== null);

    if (updateRequests.length === 0) return;

    this.loading = true;
    forkJoin(updateRequests).subscribe({
      next: () => {
        this.selectedDepartmentId = '';
        this.selectedEmployeeIds = [];
        this.loadData();
      },
      error: (err) => {
        console.error('Error updating employees:', err);
        this.loading = false;
      },
    });
  }

  getDepartmentNameById(id: string): string {
    return this.departments.find((d) => d.id === id)?.name || '';
  }
}
