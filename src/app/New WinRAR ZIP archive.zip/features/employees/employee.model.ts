export interface Employee {
  id: string;
  name: string;
  position: string;
  department: string;
  status: string;
  imageUrl: string;
  hireDate: string;
}
