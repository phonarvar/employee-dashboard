import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from './employees.service';
import { Employee } from './employee.model';
import { FormsModule } from '@angular/forms';
import { FilterPipe } from './filter.pipe';
import { EmployeeItemComponent } from './employee-item/employee-item.component';
import { EmployeeFormComponent } from './employee-form/employee-form.component'; //remember to remove form comp
import { RouterLink } from '@angular/router';
import { HoverHighlightDirective } from '../../shared/directives/hover-highlight.directive';
import { IfUserIsAdminDirective } from '../../shared/directives/if-user-is-admin.directive';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FilterPipe,
    EmployeeItemComponent,
    EmployeeFormComponent, //no longer needed for now, remove later
    HoverHighlightDirective,
    RouterLink,
    IfUserIsAdminDirective,
  ],
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss'],
})
export class EmployeesComponent implements OnInit {
  employees: Employee[] = [];
  searchTerm: string = '';

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.employees = this.employeeService.getEmployees();
  }
}
