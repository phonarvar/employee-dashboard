import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgApexchartsModule } from 'ng-apexcharts';
import { ApexAxisChartSeries, ApexChart, ApexXAxis } from 'ng-apexcharts';
import { LeaveRequestService } from '../../../core/leave-request.service';
import { LeaveRequest } from '../../../core/model';

@Component({
  selector: 'app-leave-chart',
  standalone: true,
  imports: [CommonModule, NgApexchartsModule],
  templateUrl: './leave-chart.component.html',
})
export class LeaveChartComponent implements OnInit {
  private leaveService = inject(LeaveRequestService);

  series: ApexAxisChartSeries = [];
  chart: ApexChart = {
    type: 'bar',
    height: 350,
  };
  xaxis: ApexXAxis = {
    categories: [],
  };

  ngOnInit(): void {
    this.leaveService.getLeaves().subscribe((leaves: LeaveRequest[]) => {
      const monthlyCounts: Record<string, number> = {};

      for (const leave of leaves) {
        const date = new Date(leave.createdAt);
        const month = date.toLocaleString('default', {
          month: 'short',
          year: 'numeric',
        });
        monthlyCounts[month] = (monthlyCounts[month] || 0) + 1;
      }

      this.xaxis.categories = Object.keys(monthlyCounts);
      this.series = [
        {
          name: 'Leave Requests',
          data: Object.values(monthlyCounts),
        },
      ];
    });
  }
}
